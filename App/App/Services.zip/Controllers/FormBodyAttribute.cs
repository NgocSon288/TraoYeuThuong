﻿using System;

namespace App.Controllers
{
    internal class FormBodyAttribute : Attribute
    {
    }
}